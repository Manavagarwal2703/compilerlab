#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_TOKENS 100
#define MAX_TOKEN_LENGTH 50
#define NUM_KEYWORDS 11

const char *keywords[] = {"break", "char", "const", "continue", "do", "else", "float", "for", "if", "int", "return", "while", "printf", "include"};

char identifiers[MAX_TOKENS][MAX_TOKEN_LENGTH];
char operators[MAX_TOKENS][MAX_TOKEN_LENGTH];
char keywords_found[MAX_TOKENS][MAX_TOKEN_LENGTH];
int id_count = 0, op_count = 0, kw_count = 0;

int is_keyword(const char *token) {
    for (int i = 0; i < NUM_KEYWORDS; i++) {
        if (strcmp(token, keywords[i]) == 0) {
            return 1;
        }
    }
    return 0;
}

int is_operator(char ch) {
    return (strchr("+-*/%=<>!", ch) != NULL);
}

int contains_ignore_keyword(FILE *opfile, const char *line) {

    const char *ignore_keywords[] = {"printf", "if", "else", "include", "while"};
    int ignore_count = sizeof(ignore_keywords) / sizeof(ignore_keywords[0]);
    

    for (int i = 0; i < ignore_count; i++) {
        if (strstr(line, ignore_keywords[i]) != NULL) {
            fprintf(opfile, "< keyword,%s >\n", ignore_keywords[i]);
            return 1;
        }
    }
    return 0;
}

void process_token(FILE *opfile, const char *token) {
    if(is_keyword(token)){
        strcpy(keywords_found[kw_count++],token);
        fprintf(opfile,"< keyword,%s >\n",token);
    } else if(isalpha(token[0]) || token[0]=='_'){
        strcpy(identifiers[id_count++],token);
        fprintf(opfile,"< id,%s,%s >\n",token, keywords_found[kw_count-1]);
    } else if(strlen(token)==1 && is_operator(token[0])){
        strcpy(operators[op_count++],token);
        fprintf(opfile,"< operator,%s >\n",token);
    }
}

void tokenize_line(FILE *opfile, const char *line) {
    if (contains_ignore_keyword(opfile, line)) {
        return;
    }
    
    char buffer[MAX_TOKEN_LENGTH];
    int index = 0;
    
    for (int i = 0; line[i] != '\0'; i++) {
        char ch = line[i];
        if (isalnum(ch) || ch == '_') {
            buffer[index++] = ch;
        } else {
            if (index > 0) {
                buffer[index] = '\0';
                process_token(opfile, buffer);
                index = 0;
            }            
            if (is_operator(ch)) {
                buffer[0] = ch;
                buffer[1] = '\0';
                process_token(opfile, buffer);
            }
        }
    }
    if (index > 0) {
        buffer[index] = '\0';
        process_token(opfile, buffer);
    }
}

int main() {
    FILE *file, *opfile;
    char line[1024];
    
    file = fopen("program.c", "r"); //Enter filename here

    opfile = fopen("res.txt", "w");
    if (!file || !opfile) {
        perror("Error opening file");
        return 0;
    }
    
    while (fgets(line, sizeof(line), file)) {
        tokenize_line(opfile, line);
    }
    
    fclose(file);
    fclose(opfile);
    return 0;
}