#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>

#define MAX 100

char stack[MAX];
int top = -1;

int precedence(char c) {
    if (c == '*') 
        return 3;
    else if (c == '.' || c == '|')
        return 2;
    return 0;
}

int isOperand(char c) {
    return isalpha(c);
}

void infixToPostfix(char* infix, char* postfix) {
    int i = 0, k = 0;
    char symbol;
    while (infix[i] != '\0') {
        symbol = infix[i];

        if (isOperand(symbol)) {
            postfix[k++] = symbol;
        }

        else if (symbol == '(') {
            stack[++top] = symbol;
        }

        else if (symbol == ')') {
            while (top != -1 && stack[top] != '(') {
                postfix[k++] = stack[top--];
            }
            top--;
        }

        else {
            while (top != -1 && precedence(stack[top]) >= precedence(symbol)) {
                postfix[k++] = stack[top--];
            }
            stack[++top] = symbol;
        }
        i++;
    }

    while (top != -1) {
        postfix[k++] = stack[top--];
    }
    postfix[k] = '\0';
}

typedef struct Tree {
    char alpha;
    int pos;
    bool nullable;
    int fpos[MAX];
    int lpos[MAX];
    int fpos_size;
    int lpos_size;
    struct Tree *left, *right;
} Tree;

int gpos = 0, fl_pos = 0;
int follow_pos[MAX][MAX];
int follow_size[MAX];
int state[MAX][MAX];
int state_size[MAX];
char alpha_int[MAX];
char in_alpha[MAX];
int in_alpha_size = 0;

int temp[MAX], temp_size = 0;

bool is_op(char ch) {
    return (ch == '|' || ch == '*' || ch == '.');
}

Tree* create_node(char ch, int pos) {
    Tree *node = (Tree *)malloc(sizeof(Tree));
    node->alpha = ch;
    node->pos = pos;
    node->nullable = false;
    node->fpos_size = 0;
    node->lpos_size = 0;
    node->left = node->right = NULL;
    return node;
}

void vec_add(int *a, int *size_a, int *b, int size_b) {
    for (int i = 0; i < size_b; i++) {
        bool found = false;
        for (int j = 0; j < *size_a; j++) {
            if (a[j] == b[i]) {
                found = true;
                break;
            }
        }
        if (!found) {
            a[*size_a] = b[i];
            (*size_a)++;
        }
    }
}

void print_vec(int *v, int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", v[i]);
    }
}

void postfix(Tree *root) {
    if (root) {
        postfix(root->left);
        postfix(root->right);
        printf("%c\t%d\t\t%d\t\t{", root->alpha, root->pos, root->nullable);
        print_vec(root->fpos, root->fpos_size);
        printf("}\t\t{");
        print_vec(root->lpos, root->lpos_size);
        printf("}\n");
    }
}

int main() {
    Tree *temp;
    Tree *stack[MAX];
    int top = -1;

    char str[MAX], input[MAX], infix[MAX];
    printf("\nEnter the Regular Expression = ");
    scanf("%s", infix);
    str[strcspn(infix, "\n")] = 0;
    printf("Augmented String = %s#\n", infix);

    infixToPostfix(infix, str);
    strcat(str,"#.");

    for (int i = 0; str[i]; i++) {
        if (!is_op(str[i])) {
            gpos++;
            if (str[i] != '#') {
                fl_pos++;
                alpha_int[fl_pos] = str[i];
                bool exists = false;
                for (int j = 0; j < in_alpha_size; j++) {
                    if (in_alpha[j] == str[i]) {
                        exists = true;
                        break;
                    }
                }
                if (!exists) {
                    in_alpha[in_alpha_size++] = str[i];
                }
            }
            temp = create_node(str[i], gpos);
            temp->nullable = false;
            temp->fpos[temp->fpos_size++] = gpos;
            temp->lpos[temp->lpos_size++] = gpos;
        } else if (str[i] == '*') {
            temp = create_node(str[i], 0);
            temp->left = stack[top--];
            temp->nullable = true;
            memcpy(temp->fpos, temp->left->fpos, temp->left->fpos_size * sizeof(int));
            temp->fpos_size = temp->left->fpos_size;
            memcpy(temp->lpos, temp->left->lpos, temp->left->lpos_size * sizeof(int));
            temp->lpos_size = temp->left->lpos_size;
            for (int j = 0; j < temp->lpos_size; j++) {
                int pos = temp->lpos[j];
                vec_add(follow_pos[pos], &follow_size[pos], temp->fpos, temp->fpos_size);
            }
        } else if (str[i] == '.') {
            temp = create_node(str[i], 0);
            temp->right = stack[top--];
            temp->left = stack[top--];
            temp->nullable = temp->left->nullable && temp->right->nullable;
            if (temp->left->nullable) {
                vec_add(temp->fpos, &temp->fpos_size, temp->left->fpos, temp->left->fpos_size);
                vec_add(temp->fpos, &temp->fpos_size, temp->right->fpos, temp->right->fpos_size);
            } else {
                vec_add(temp->fpos, &temp->fpos_size, temp->left->fpos, temp->left->fpos_size);
            }
            if (temp->right->nullable) {
                vec_add(temp->lpos, &temp->lpos_size, temp->left->lpos, temp->left->lpos_size);
                vec_add(temp->lpos, &temp->lpos_size, temp->right->lpos, temp->right->lpos_size);
            } else {
                vec_add(temp->lpos, &temp->lpos_size, temp->right->lpos, temp->right->lpos_size);
            }
            for (int j = 0; j < temp->left->lpos_size; j++) {
                int pos = temp->left->lpos[j];
                vec_add(follow_pos[pos], &follow_size[pos], temp->right->fpos, temp->right->fpos_size);
            }
        } else {
            temp = create_node(str[i], 0);
            temp->right = stack[top--];
            temp->left = stack[top--];
            temp->nullable = temp->left->nullable && temp->right->nullable;
            vec_add(temp->fpos, &temp->fpos_size, temp->left->fpos, temp->left->fpos_size);
            vec_add(temp->fpos, &temp->fpos_size, temp->right->fpos, temp->right->fpos_size);
            vec_add(temp->lpos, &temp->lpos_size, temp->left->lpos, temp->left->lpos_size);
            vec_add(temp->lpos, &temp->lpos_size, temp->right->lpos, temp->right->lpos_size);
        }
        stack[++top] = temp;
    }

    for (int i = 0; i < in_alpha_size; i++) {
        input[i] = in_alpha[i];
    }
    input[in_alpha_size] = '\0';

    printf("\n\nNODE\tPosition\tNullable\tFirstPos\tLastPos\n");
    postfix(stack[top]);

    printf("\n\nFollow Position:\n");
    for (int i = 1; i <= fl_pos; i++) {
        printf("%d %c { ", i, alpha_int[i]);
        print_vec(follow_pos[i], follow_size[i]);
        printf(" }\n");
    }

    return 0;
}