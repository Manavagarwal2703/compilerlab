#include <ctype.h>
#include <stdio.h>
#include <string.h>

void followfirst(char, int, int);

int count, n = 0;
char calc_first[10][100];
char calc_follow[10][100];
int m = 0;
char production[10][10];
char f[10], first[10];
int k;
char ck;
int e;

char first_array[10][10];
char follow_array[10][10];

void follow(char c) {
    if (production[0][0] == c) {
        f[m++] = '$';
    }
    for (int i = 0; i < 10; i++) {
        for (int j = 3; j < 10; j++) {
            if (production[i][j] == c) {
                if (production[i][j + 1] != '\0') {
                    followfirst(production[i][j + 1], i, (j + 2));
                }
                if (production[i][j + 1] == '\0' && c != production[i][0]) {
                    follow(production[i][0]);
                }
            }
        }
    }
}

void findfirst(char c, int q1, int q2) {
    int j;
    if (!(isupper(c))) {
        first[n++] = c;
    }
    for (j = 0; j < count; j++) {
        if (production[j][0] == c) {
            if (production[j][3] == 'e') {
                if (production[q1][q2] == '\0')
                    first[n++] = 'e';
                else if (production[q1][q2] != '\0' && (q1 != 0 || q2 != 0)) {
                    findfirst(production[q1][q2], q1, (q2 + 1));
                } else
                    first[n++] = 'e';
            } else if (!isupper(production[j][3])) {
                first[n++] = production[j][3];
            } else {
                findfirst(production[j][3], j, 4);
            }
        }
    }
}

void followfirst(char c, int c1, int c2) {
    int k;
    if (!(isupper(c)))
        f[m++] = c;
    else {
        int i = 0, j = 1;
        for (i = 0; i < count; i++) {
            if (calc_first[i][0] == c)
                break;
        }
        while (calc_first[i][j] != '!') {
            if (calc_first[i][j] != 'e') {
                f[m++] = calc_first[i][j];
            } else {
                if (production[c1][c2] == '\0') {
                    follow(production[c1][0]);
                } else {
                    followfirst(production[c1][c2], c1, c2 + 1);
                }
            }
            j++;
        }
    }
}

void parser(int count, int rules_count){
    printf("\n");
    for(int i=0;i<rules_count;i++){
        char temp=production[i][3];
        if(temp=='e'){
            for(int j=0;j<count;j++){
                if(follow_array[j][0]==production[i][0]){
                    int k=1;
                    char c=follow_array[j][k++];
                    
                    while(c!='!'){
                        printf("M[%c,%c]= %s\n",production[i][0],c,production[i]);
                        c=follow_array[j][k++];
                        
                    }
                }
            }
        }

        else if(!isupper(temp)){
            printf("M[%c,%c]= %s\n",production[i][0],temp,production[i]);
        }
        

        else{
            for(int j=0;j<count;j++){
                if(first_array[j][0]==temp){
                    int k=1;
                    char c=first_array[j][k++];
                    while(c!='!'){
                        if(c!='e'){
                            printf("M[%c,%c]= %s\n",production[i][0],c,production[i]);
                        }
                        c=first_array[j][k++];
                        
                    }
                }
            }
        }
    }
}

int main() {
    int jm = 0;
    int km = 0;
    int i,j=0;
    char c;

    printf("Enter the number of production rules: ");
    scanf("%d", &count);
    getchar();

    printf("Enter the production rules:\n");
    for (i = 0; i < count; i++) {
        char temp[10], lhs[10], rhs[20];
        fgets(temp, 20, stdin);
        temp[strcspn(temp, "\n")] = '\0';

        char *arrow = strstr(temp, "->");

        int lhs_len = arrow - temp;
        strncpy(lhs, temp, lhs_len);
        lhs[lhs_len] = '\0';

        strcpy(rhs, arrow + 2);

        char *token = strtok(rhs, "|");
        while (token != NULL) {
            snprintf(production[j++], 20, "%s->%s", lhs, token);
            token = strtok(NULL, "|");
        }
    }

    count=j;
    int kay;
    char done[count];
    int ptr = -1;

    for (k = 0; k < count; k++) {
        for (kay = 0; kay < 100; kay++) {
            calc_first[k][kay] = '!';
            first_array[k][kay] = '!';
        }
    }
    int point1 = 0, point2, xxx;

    for (k = 0; k < count; k++) {
        c = production[k][0];
        point2 = 0;
        xxx = 0;

        for (kay = 0; kay <= ptr; kay++)
            if (c == done[kay])
                xxx = 1;

        if (xxx == 1)
            continue;

        findfirst(c, 0, 0);
        ptr += 1;

        done[ptr] = c;
        calc_first[point1][point2++] = c;
        first_array[point1][0] = c;

        for (i = 0 + jm; i < n; i++) {
            int lark = 0, chk = 0;

            for (lark = 0; lark < point2; lark++) {
                if (first[i] == calc_first[point1][lark]) {
                    chk = 1;
                    break;
                }
            }
            if (chk == 0) {
                calc_first[point1][point2] = first[i];
                first_array[point1][point2++] = first[i];
            }
        }
        jm = n;
        point1++;
    }

    printf("\n\n");
    
    char donee[count];
    ptr = -1;

    for (k = 0; k < count; k++) {
        for (kay = 0; kay < 100; kay++) {
            calc_follow[k][kay] = '!';
            follow_array[k][kay] = '!';
        }
    }
    point1 = 0;
    int land = 0;
    for (e = 0; e < count; e++) {
        ck = production[e][0];
        point2 = 0;
        xxx = 0;

        for (kay = 0; kay <= ptr; kay++)
            if (ck == donee[kay])
                xxx = 1;

        if (xxx == 1)
            continue;
        land += 1;

        follow(ck);
        ptr += 1;

        donee[ptr] = ck;
        calc_follow[point1][point2++] = ck;
        follow_array[point1][0] = ck;

        for (i = 0 + km; i < m; i++) {
            int lark = 0, chk = 0;
            for (lark = 0; lark < point2; lark++) {
                if (f[i] == calc_follow[point1][lark]) {
                    chk = 1;
                    break;
                }
            }
            if (chk == 0) {
                calc_follow[point1][point2] = f[i];
                follow_array[point1][point2++] = f[i];
            }
        }
        km = m;
        point1++;
    }

    printf("\nStored First Sets:\n");
    for (i = 0; i < count; i++) {
        if (first_array[i][0] != '!') {
            printf("First(%c) = { ", first_array[i][0]);
            for (j = 1; first_array[i][j] != '!'; j++)
                printf("%c ", first_array[i][j]);
            printf("}\n");
        }
    }

    printf("\nStored Follow Sets:\n");
    for (i = 0; i < count; i++) {
        if (follow_array[i][0] != '!') {
            printf("Follow(%c) = { ", follow_array[i][0]);
            for (j = 1; follow_array[i][j] != '!'; j++)
                printf("%c ", follow_array[i][j]);
            printf("}\n");
        }
    }

    parser(point1,count);

    return 0;
}