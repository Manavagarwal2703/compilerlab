#include <stdio.h>  
#include <string.h>  
#include <stdbool.h>

#define SIZE 10  
#define MAX_PRODUCTIONS 10  
#define MAX_LENGTH 50  

char getUnusedChar(bool used_chars[]) {
    for (char c = 'Z'; c >= 'A'; c--) {
        if (!used_chars[c - 'A']) {
            used_chars[c - 'A'] = true;
            return c;
        }
    }
    return 'x';
}

struct production {
    int length;
    char prod[10][10];
} typedef production;

struct grammer {
    int number;
    production nonT[26];
} typedef grammer;

grammer gram;

void printProd(production *);
void printGram();

int getF(char *str) {
    int i = 1;
    while (i < strlen(str) && str[i - 1] != '>') i++;
    while (i < strlen(str) && str[i] == ' ') i++;
    return i;
}

void setProd(char *str) {
    production *produce = &gram.nonT[str[0] - 'A'];
    int prod = 0, j;
    for (int i = getF(str); i < strlen(str); i++) {
        for (j = 0; i < strlen(str) && str[i] != '|'; i++)
            if (str[i] != ' ')
                produce->prod[prod][j++] = str[i];
        produce->prod[prod++][j++] = '\0';
    }
    produce->length = prod;
}

void copy(char *src, char *dest, int i) {
    int j = i + 1;
    do {
        dest[j - i - 1] = src[j];
    } while (src[j++] != '\0');
    if (dest[0] == '\0') {
        dest[0] = 'e';
        dest[1] = '\0';
    }
}

bool factorProd(production *prod) {
    bool prev[10] = {1, 1, 1, 1, 1, 1, 1, 1, 1, 1};
    bool next[10] = {0};
    char c[128] = {0}, ch;
    int j = 0, maxx;
    while (true) {
        maxx = 0;
        for (int i = 0; i < 10; i++)
            if (prev[i] && strlen(prod->prod[i]) > j)
                c[prod->prod[i][j]]++;

        for (int i = 0; i < 128; i++) {
            if (c[i] > maxx) maxx = c[i], ch = i;
            c[i] = 0;
        }

        if (maxx < 2) break;

        for (int i = 0; i < 10; i++)
            prev[i] = j < strlen(prod->prod[i]) && prod->prod[i][j] == ch;
        j++;
    }

    if (j == 0) return false;

    int newNonT = 0, p_no = 0;
    while (gram.nonT[newNonT].length != 0) newNonT++;

    production *newP = &gram.nonT[newNonT];

    for (int i = 0; i < 10; i++)
        if (prev[i] && prod->prod[i][0] != '\0') {
            copy(prod->prod[i], newP->prod[p_no], j - 1);
            prod->prod[i][j] = newNonT + 'A';
            prod->prod[i][j + 1] = '\0';
            p_no++;
        }
    gram.number++;
    newP->length = p_no;

    int i = 0, num = 0;
    while (prev[i] == false) i++;
    for (i++; i < 10; i++)
        if (prev[i] && prod->prod[i][0] != '\0')
            prod->prod[i][0] = '\0', num++;

    prod->length -= num;
    return true;
}

void leftFactor() {
    for (int i = 0; i < 26; i++) {
        if (gram.number == 26) {
            printf("New productions > 26.\n");
            return;
        }
        if (gram.nonT[i].length >= 2)
            while (factorProd(&gram.nonT[i])) { }
    }
}

int main() {  
    char non_terminal, beta[10], alpha;  
    int num;  
    char productions[MAX_PRODUCTIONS][SIZE];  
    char results[MAX_PRODUCTIONS * 2][MAX_LENGTH];  
    int result_count = 0;  
    int index = 3;  

    bool used_chars[26] = { false };

    printf("Enter Number of Productions: ");  
    scanf("%d", &num);
    gram.number=num;

    printf("Enter the grammar (e is epsilon):\n");  
    for (int i = 0; i < num; i++) {  
        scanf("%s", productions[i]);  
        used_chars[productions[i][0] - 'A'] = true;
    }  

    for (int i = 0; i < num; i++) {  
        non_terminal = productions[i][0];
        if (non_terminal == productions[i][index]) {  
            alpha = productions[i][index + 1];  
            while (productions[i][index] != 0 && productions[i][index] != '|')  
                index++;

            if (productions[i][index] != 0) {
                int z = 0;
                index++;

                while (productions[i][index] != 0 && productions[i][index] != '|') {
                    beta[z++] = productions[i][index++];
                }
                beta[z] = '\0';

                char new_char = getUnusedChar(used_chars);

                sprintf(results[result_count++], "%c->%s%c", non_terminal, beta, new_char);
                sprintf(results[result_count++], "%c->%c%c|e", new_char, alpha, new_char);
                gram.number++;
            } else {
                sprintf(results[result_count++], "%s can't be reduced", productions[i]);
            }
        } else {
            sprintf(results[result_count++], "%s", productions[i]);
        }
        index = 3;  
    }  

    printf("\nRemoving Left Recursion:\n");
    for (int i = 0; i < result_count; i++) {  
        printf("%s\n", results[i]);
        setProd(results[i]);
    }

    leftFactor();
    printf("\n\nAfter Left Factoring");
    printGram();
    printf("\n");
    return 0;

    return 0;  
}

void printProd(production *prod) {
    printf("%s ", prod->prod[0]);
    for (int i = 1; i < 10; i++)
        if (prod->prod[i][0] != '\0')
            printf("| %s ", prod->prod[i]);
}

void printGram() {
    for (int i = 0; i < 26; i++)
        if (gram.nonT[i].length) {
            printf("\n%c -> ", i + 'A');
            printProd(&gram.nonT[i]);
        }
}